/*
 * TODO: comment this program
 */

import stanford.karel.*;

public class StoneMason extends SuperKarel {
	
	public void run() {
		// TODO: write the code to implement this program
	}

}
