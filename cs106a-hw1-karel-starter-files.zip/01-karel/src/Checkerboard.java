/*
 * TODO: comment this program
 */

import stanford.karel.*;

public class Checkerboard extends SuperKarel {
	
	public void run() {
		// TODO: write the code to implement this program
	}

}
