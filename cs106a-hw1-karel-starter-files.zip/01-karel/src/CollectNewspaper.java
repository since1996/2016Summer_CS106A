/*
 * TODO: comment this program
 */

import stanford.karel.*;

public class CollectNewspaper extends SuperKarel {
	
	public void run() {
		// TODO: write the code to implement this program
	}
}
