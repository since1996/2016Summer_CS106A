/*
 * File: Target.java
 * Name:
 * Section Leader:
 * -----------------
 * TODO: add a program comment 
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Target extends GraphicsProgram {	
	
	public void run() {
		// TODO: implement this program
	}
	
}