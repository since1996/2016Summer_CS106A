/*
 * File: ExamScores.java
 * Name:
 * Section Leader:
 * --------------------
 * TODO: add a program comment
 */

import acm.program.*;

public class ExamScores extends ConsoleProgram { 
	
	public void run() {
		// TODO: implement this program
	}
}