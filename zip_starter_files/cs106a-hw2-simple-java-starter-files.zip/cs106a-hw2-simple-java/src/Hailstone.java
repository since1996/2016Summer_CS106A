/*
 * File: Hailstone.java
 * Name:
 * Section Leader:
 * --------------------
 * TODO: add a program comment 
 */

import acm.program.*;

public class Hailstone extends ConsoleProgram {
	
	public void run() {
		// TODO: implement this program
	}
}